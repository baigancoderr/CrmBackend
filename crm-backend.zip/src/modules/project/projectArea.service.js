const storageService = require("../../services/storage.service");
const ProjectArea = require("./projectArea.model");
const Project = require("./project.model");
const Task = require("./task/task.model");
const User = require("../user/user.model");
const AreaDocument = require("./areaDocument.model");
const projectService = require("./project.service");
const {
  createAppError,
  logProjectActivity,
  calcProjectProgress,
  deriveAreaStatusFromTasks,
  USER_POPULATE,
} = require("./project.helper");
const { PM_ROLES } = require("./project.constants");

/** Team Leads and employees only see work areas they lead or hold a task in. */
const isSelfScopedAreaViewer = (role) => ["TL", "EMPLOYEE"].includes(role);

const buildSelfScopedAreaFilter = async (projectId, user) => {
  const assignedAreaIds = await Task.distinct("projectAreaId", {
    projectId,
    assignedTo: user.id,
    isArchived: false,
  });

  return {
    $or: [
      { teamLead: user.id },
      { projectLead: user.id },
      { _id: { $in: assignedAreaIds } },
    ],
  };
};

const buildAreaDocumentMeta = async (file) => ({
  fileName: file.originalname,
  fileUrl: await storageService.persistUploadedFile(file, "areas"),
  fileSize: file.size,
  mimeType: file.mimetype,
});

const saveAreaDocuments = async (projectId, areaId, user, files = []) => {
  if (!files?.length) return [];
  const docs = [];
  for (const file of files) {
    const doc = await AreaDocument.create({
      areaId,
      projectId,
      title: file.originalname,
      ...(await buildAreaDocumentMeta(file)),
      uploadedBy: user.id,
      uploadedByNameSnapshot: user.name,
    });
    docs.push(doc);
  }
  return docs;
};

const createArea = async (projectId, user, payload, files = []) => {
  const project = await projectService.assertProjectAccess(projectId, user, { write: true });
  if (!PM_ROLES.includes(user.role)) {
    const project = await projectService.getProjectById(projectId, user);
    if (String(project.projectManager) !== String(user.id)) {
      throw createAppError("Only Project Manager can create work areas.", 403);
    }
  }

  const title = String(payload.title || "").trim();
  if (!title) throw createAppError("Work area title is required.", 422);

  let teamLeadNameSnapshot = "";
  if (payload.teamLead) {
    const tl = await User.findById(payload.teamLead).select("name");
    if (!tl) throw createAppError("Team Lead not found.", 404);
    teamLeadNameSnapshot = tl.name;
  }

  let projectLeadNameSnapshot = "";
  if (payload.projectLead) {
    const lead = await User.findById(payload.projectLead).select("name");
    if (!lead) throw createAppError("Project Lead not found.", 404);
    projectLeadNameSnapshot = lead.name;
  }

  // Prevent area dates falling on weekends unless project includes weekends
  if (!project.includeWeekends) {
    if (payload.startDate) {
      const sd = new Date(payload.startDate);
      const day = sd.getDay();
      if (day === 0 || day === 6) throw createAppError("Project does not include weekends; area start date cannot be on weekend.", 422);
    }
    if (payload.estimatedEndDate) {
      const ed = new Date(payload.estimatedEndDate);
      const day = ed.getDay();
      if (day === 0 || day === 6) throw createAppError("Project does not include weekends; area estimated end date cannot be on weekend.", 422);
    }
  }

  const area = await ProjectArea.create({
    title,
    description: String(payload.description || "").trim(),
    projectId,
    teamLead: payload.teamLead || null,
    teamLeadNameSnapshot,
    startDate: payload.startDate ? new Date(payload.startDate) : null,
    estimatedEndDate: payload.estimatedEndDate ? new Date(payload.estimatedEndDate) : null,
    projectLead: payload.projectLead || null,
    projectLeadNameSnapshot,
    status: "NOT_STARTED",
    progress: 0,
    sortOrder: payload.sortOrder || 0,
    createdBy: user.id,
  });

  if (payload.teamLead) {
    await projectService.ensureAssignedUserProjectMembership({
      projectId,
      userId: payload.teamLead,
      userName: teamLeadNameSnapshot,
      role: "TEAM_LEAD",
      projectAreaId: area._id,
      addedBy: user.id,
    });
  }
  if (payload.projectLead) {
    await projectService.ensureAssignedUserProjectMembership({
      projectId,
      userId: payload.projectLead,
      userName: projectLeadNameSnapshot,
      role: "MEMBER",
      projectAreaId: area._id,
      addedBy: user.id,
    });
  }

  await saveAreaDocuments(projectId, area._id, user, files);

  await logProjectActivity({
    projectId,
    user,
    action: "AREA_CREATED",
    module: "AREA",
    entityType: "ProjectArea",
    entityId: area._id,
    newValue: { title, teamLead: payload.teamLead, projectLead: payload.projectLead },
  });

  // First work area moves project from Planning → Active
  const projectDoc = await Project.findById(projectId);
  if (projectDoc && projectDoc.status === "PLANNING") {
    const previousStatus = projectDoc.status;
    projectDoc.status = "ACTIVE";
    await projectDoc.save();
    await logProjectActivity({
      projectId,
      user,
      action: "PROJECT_STATUS_CHANGED",
      module: "PROJECT",
      entityType: "Project",
      entityId: projectId,
      oldValue: { status: previousStatus },
      newValue: { status: "ACTIVE", reason: "Auto-activated when first work area was created" },
    });
  }

  const createdArea = await ProjectArea.findById(area._id)
    .populate("teamLead", USER_POPULATE)
    .populate("projectLead", USER_POPULATE)
    .lean();
  const documents = await AreaDocument.find({ areaId: area._id }).sort({ createdAt: -1 }).lean();
  await projectService.refreshProjectMetrics(projectId);
  return { ...createdArea, documents, projectStatus: projectDoc?.status || "ACTIVE" };
};

const listAreas = async (projectId, user, query = {}) => {
  await projectService.assertProjectAccess(projectId, user);
  const filter = { projectId };
  if (query.status) filter.status = query.status;
  if (query.archived === "true") filter.isArchived = true;
  else filter.isArchived = false;

  if (isSelfScopedAreaViewer(user.role)) {
    Object.assign(filter, await buildSelfScopedAreaFilter(projectId, user));
  }

  const areas = await ProjectArea.find(filter)
    .sort({ sortOrder: 1, createdAt: 1 })
    .populate("teamLead", USER_POPULATE)
    .populate("projectLead", USER_POPULATE)
    .lean();

  const areaIds = areas.map((a) => a._id);
  const [tasks, documents] = await Promise.all([
    Task.find({ projectAreaId: { $in: areaIds }, isArchived: false })
      .select("projectAreaId status")
      .lean(),
    AreaDocument.find({ areaId: { $in: areaIds } }).sort({ createdAt: -1 }).lean(),
  ]);

  const documentsByArea = documents.reduce((acc, doc) => {
    const key = String(doc.areaId);
    if (!acc[key]) acc[key] = [];
    acc[key].push(doc);
    return acc;
  }, {});

  return areas.map((area) => {
    const areaTasks = tasks.filter((t) => String(t.projectAreaId) === String(area._id));
    return {
      ...area,
      progress: calcProjectProgress(areaTasks),
      status: deriveAreaStatusFromTasks(areaTasks),
      taskCount: areaTasks.length,
      documents: documentsByArea[String(area._id)] || [],
    };
  });
};

const updateArea = async (projectId, areaId, user, payload) => {
  const project = await projectService.assertProjectAccess(projectId, user, { write: true });
  const area = await ProjectArea.findOne({ _id: areaId, projectId });
  if (!area) throw createAppError("Work area not found.", 404);

  const isPM = PM_ROLES.includes(user.role);
  const isAreaTL = String(area.teamLead) === String(user.id);
  const isProjectLead = String(area.projectLead) === String(user.id);
  if (!isPM && !isAreaTL && !isProjectLead) throw createAppError("Access denied.", 403);

  const oldValue = area.toObject();

  if (payload.title !== undefined) area.title = String(payload.title).trim();
  if (payload.description !== undefined) area.description = String(payload.description).trim();
  if (payload.status !== undefined) {
    throw createAppError(
      "Work area status is automatic based on task progress and cannot be changed manually.",
      422
    );
  }
  if (payload.teamLead !== undefined && isPM) {
    area.teamLead = payload.teamLead || null;
    if (payload.teamLead) {
      const tl = await User.findById(payload.teamLead).select("name");
      area.teamLeadNameSnapshot = tl?.name || "";
    }
  }
  // Prevent area dates falling on weekends unless project includes weekends
  if (!project.includeWeekends) {
    if (payload.startDate) {
      const sd = new Date(payload.startDate);
      const day = sd.getDay();
      if (day === 0 || day === 6) throw createAppError("Project does not include weekends; area start date cannot be on weekend.", 422);
    }
    if (payload.estimatedEndDate) {
      const ed = new Date(payload.estimatedEndDate);
      const day = ed.getDay();
      if (day === 0 || day === 6) throw createAppError("Project does not include weekends; area estimated end date cannot be on weekend.", 422);
    }
  }

  if (payload.startDate !== undefined) area.startDate = payload.startDate ? new Date(payload.startDate) : null;
  if (payload.estimatedEndDate !== undefined) area.estimatedEndDate = payload.estimatedEndDate ? new Date(payload.estimatedEndDate) : null;
  if (payload.projectLead !== undefined && isPM) {
    area.projectLead = payload.projectLead || null;
    if (payload.projectLead) {
      const lead = await User.findById(payload.projectLead).select("name");
      area.projectLeadNameSnapshot = lead?.name || "";
    }
  }

  await area.save();

  if (payload.teamLead) {
    await projectService.ensureAssignedUserProjectMembership({
      projectId,
      userId: area.teamLead,
      userName: area.teamLeadNameSnapshot,
      role: "TEAM_LEAD",
      projectAreaId: area._id,
      addedBy: user.id,
    });
  }
  if (payload.projectLead) {
    await projectService.ensureAssignedUserProjectMembership({
      projectId,
      userId: area.projectLead,
      userName: area.projectLeadNameSnapshot,
      role: "MEMBER",
      projectAreaId: area._id,
      addedBy: user.id,
    });
  }

  await logProjectActivity({
    projectId,
    user,
    action: "AREA_UPDATED",
    module: "AREA",
    entityType: "ProjectArea",
    entityId: area._id,
    oldValue: { title: oldValue.title },
    newValue: { title: area.title },
    reason: payload.reason || "",
  });

  const areaTasks = await Task.find({ projectAreaId: area._id, isArchived: false })
    .select("status")
    .lean();
  const derivedStatus = deriveAreaStatusFromTasks(areaTasks);
  const derivedProgress = calcProjectProgress(areaTasks);
  if (area.status !== derivedStatus || area.progress !== derivedProgress) {
    area.status = derivedStatus;
    area.progress = derivedProgress;
    await area.save();
  }

  const updated = await ProjectArea.findById(area._id)
    .populate("teamLead", USER_POPULATE)
    .populate("projectLead", USER_POPULATE)
    .lean();
  return {
    ...updated,
    progress: derivedProgress,
    status: derivedStatus,
    taskCount: areaTasks.length,
  };
};

const deleteArea = async (projectId, areaId, user) => {
  await projectService.assertProjectAccess(projectId, user, { write: true });
  const area = await ProjectArea.findOne({ _id: areaId, projectId });
  if (!area) throw createAppError("Work area not found.", 404);

  const isPM = PM_ROLES.includes(user.role);
  const isAreaTL = String(area.teamLead) === String(user.id);
  const isProjectLead = String(area.projectLead) === String(user.id);
  if (!isPM && !isAreaTL && !isProjectLead) throw createAppError("Access denied.", 403);

  area.isArchived = true;
  area.archivedAt = new Date();
  area.archivedBy = user.id;
  await area.save();

  await Task.updateMany({ projectAreaId: area._id, status: { $ne: "ARCHIVED" } }, { status: "ARCHIVED", isArchived: true });

  await logProjectActivity({
    projectId,
    user,
    action: "AREA_ARCHIVED",
    module: "AREA",
    entityType: "ProjectArea",
    entityId: area._id,
    oldValue: { status: area.status, title: area.title },
    newValue: { isArchived: true },
    description: "Work area archived.",
  });

  await projectService.refreshProjectMetrics(projectId);

  return ProjectArea.findById(area._id).populate("teamLead", USER_POPULATE).populate("projectLead", USER_POPULATE);
};

const assignTeamLead = async (projectId, areaId, user, payload) => {
  if (!PM_ROLES.includes(user.role)) {
    const project = await projectService.getProjectById(projectId, user);
    if (String(project.projectManager) !== String(user.id)) {
      throw createAppError("Only Project Manager can assign Team Lead.", 403);
    }
  }

  const area = await ProjectArea.findOne({ _id: areaId, projectId });
  if (!area) throw createAppError("Work area not found.", 404);

  const teamLeadId = payload.teamLead;
  const tl = await User.findOne({ _id: teamLeadId, isActive: true, role: { $in: ["TL", "PROJECT_MANAGER"] } });
  if (!tl) throw createAppError("Valid Team Lead not found.", 404);

  area.teamLead = tl._id;
  area.teamLeadNameSnapshot = tl.name;
  if (area.status === "NOT_STARTED") area.status = "IN_PROGRESS";
  await area.save();

  await projectService.ensureAssignedUserProjectMembership({
    projectId,
    userId: tl._id,
    userName: tl.name,
    role: "TEAM_LEAD",
    projectAreaId: area._id,
    addedBy: user.id,
  });

  await logProjectActivity({
    projectId,
    user,
    action: "AREA_TEAM_LEAD_ASSIGNED",
    module: "AREA",
    entityType: "ProjectArea",
    entityId: area._id,
    newValue: { teamLead: tl._id, name: tl.name },
  });

  return ProjectArea.findById(area._id).populate("teamLead", USER_POPULATE).populate("projectLead", USER_POPULATE);
};

const uploadAreaDocuments = async (projectId, areaId, user, files = []) => {
  await projectService.assertProjectAccess(projectId, user, { write: true });
  if (!PM_ROLES.includes(user.role)) {
    throw createAppError("Only Project Manager, HR, or Super Admin can add work area documents.", 403);
  }
  const area = await ProjectArea.findOne({ _id: areaId, projectId });
  if (!area) throw createAppError("Work area not found.", 404);
  return saveAreaDocuments(projectId, area._id, user, files);
};

const deleteAreaDocument = async (projectId, areaId, docId, user) => {
  await projectService.assertProjectAccess(projectId, user, { write: true });
  if (!PM_ROLES.includes(user.role)) {
    throw createAppError("Only Project Manager, HR, or Super Admin can remove work area documents.", 403);
  }
  const area = await ProjectArea.findOne({ _id: areaId, projectId });
  if (!area) throw createAppError("Work area not found.", 404);

  const document = await AreaDocument.findOne({ _id: docId, projectId, areaId });
  if (!document) throw createAppError("Document not found.", 404);

  await AreaDocument.deleteOne({ _id: docId });

  await storageService.deleteStoredFile(document.fileUrl);

  return document;
};

const listAreaDocuments = async (projectId, areaId, user) => {
  await projectService.assertProjectAccess(projectId, user);
  const filter = { _id: areaId, projectId };
  if (isSelfScopedAreaViewer(user.role)) {
    Object.assign(filter, await buildSelfScopedAreaFilter(projectId, user));
  }
  const area = await ProjectArea.findOne(filter);
  if (!area) throw createAppError("Work area not found.", 404);
  return AreaDocument.find({ projectId, areaId }).sort({ createdAt: -1 }).lean();
};

const getAreaById = async (projectId, areaId, user) => {
  await projectService.assertProjectAccess(projectId, user);
  const filter = { _id: areaId, projectId, isArchived: false };
  if (isSelfScopedAreaViewer(user.role)) {
    Object.assign(filter, await buildSelfScopedAreaFilter(projectId, user));
  }

  const area = await ProjectArea.findOne(filter)
    .populate("teamLead", USER_POPULATE)
    .populate("projectLead", USER_POPULATE)
    .lean();
  if (!area) throw createAppError("Work area not found.", 404);

  // Progress is derived the same way as in listAreas so both screens agree.
  const [documents, areaTasks] = await Promise.all([
    AreaDocument.find({ areaId: area._id }).sort({ createdAt: -1 }).lean(),
    Task.find({ projectAreaId: area._id, isArchived: false }).select("status").lean(),
  ]);

  return {
    ...area,
    progress: calcProjectProgress(areaTasks),
    status: deriveAreaStatusFromTasks(areaTasks),
    taskCount: areaTasks.length,
    documents,
  };
};

module.exports = {
  createArea,
  listAreas,
  getAreaById,
  updateArea,
  assignTeamLead,
  uploadAreaDocuments,
  deleteArea,
  deleteAreaDocument,
  listAreaDocuments,
};
